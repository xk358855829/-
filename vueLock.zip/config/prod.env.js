'use strict'
module.exports = {
  NODE_ENV: '"production"',
  API_ROOT:'"http://39.104.113.112:2089"'//家庭
  // API_ROOT:'"http://39.104.113.112:20189"'//客服
}

